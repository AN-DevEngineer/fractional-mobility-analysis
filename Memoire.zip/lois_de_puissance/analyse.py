# ./lois_de_puissance/analyse.py
#
# ANALYSE COMPLETE D'UNE DISTRIBUTION : UNE LIGNE DE RESULTATS PAR VARIABLE
#
# Assemble clauset.py (ajustement et adequation) et alternatives.py (concurrence des lois) et rend un
# dictionnaire a plat, directement exploitable comme ligne de CSV.
#
# ----------------------------------------------------------------------------------------
# Le verdict, et ce qu'il veut (et ne veut pas) dire
# ----------------------------------------------------------------------------------------
#   "rejetee"               p de l'adequation <= LP_SEUIL_P : les donnees ne sont pas compatibles avec
#                           une loi de puissance (regle de Clauset).
#   "alternative_meilleure" la loi de puissance n'est pas rejetee, MAIS au moins une alternative est
#                           significativement meilleure (rapport de vraisemblance significatif).
#   "plausible"             la loi de puissance n'est pas rejetee et aucune alternative n'est
#                           significativement meilleure. Cela ne PROUVE pas la loi de puissance :
#                           cela veut dire que les donnees ne permettent pas de l'ecarter.
#   "insuffisant"           trop peu de donnees pour ajuster.
#   "indetermine"           l'ajustement a eu lieu mais la p-valeur n'a pas pu etre calculee.
#
# ----------------------------------------------------------------------------------------
# Lien avec l'hypothese H2 (memoire longue et alternance mouvement / arret)
# ----------------------------------------------------------------------------------------
# Un processus ON/OFF dont les durees ont une queue en loi de puissance de SURVIE a, avec 1 < a < 2,
# est a dependance longue avec H = (3 - a) / 2 (Taqqu, Willinger & Sherman, 1997 ; formule a
# confronter a la source avant publication).
#
# Notre alpha est l'exposant de la DENSITE : a = alpha - 1. La condition 1 < a < 2 devient donc
#                     2 < alpha < 3,        et        H = (3 - (alpha - 1)) / 2 = (4 - alpha) / 2.
# C'est le point delicat : les exposants de densite publies pour les temps de sejour sont plutot
# de 1.2 a 2.0, donc a la limite ou en dehors de ce domaine. Les colonnes `dans_domaine_on_off` et
# `h_on_off_predit` servent a verifier cela AVANT de comparer quoi que ce soit a H : si alpha est
# hors domaine, la prediction ne s'applique pas et on le rapporte tel quel.

import numpy as np

from config import LP_NB_BOOTSTRAP, LP_NB_CANDIDATS_XMIN, LP_NB_MIN_QUEUE, LP_SEUIL_P
from lois_de_puissance.alternatives import NOMS_ALTERNATIVES, NOMS_MODELES, comparer_modeles
from lois_de_puissance.clauset import ajuster_loi_de_puissance, p_valeur_adequation

NAN = float("nan")


def _resultat_vide(n, verdict="insuffisant"):
    """Ligne de resultats sans ajustement : toutes les colonnes existent (CSV rectangulaire)."""
    ligne = dict(n=int(n), xmin=NAN, alpha=NAN, sigma_alpha=NAN, n_queue=0, part_queue=NAN, ks=NAN,
                 p_bootstrap=NAN, nb_bootstrap=0, exposant_survie=NAN, dans_domaine_on_off=False,
                 h_on_off_predit=NAN, verdict=verdict, alternatives_meilleures="", meilleur_modele="")
    for nom in NOMS_MODELES:
        ligne[f"poids_aicc_{nom}"] = NAN
    for nom in NOMS_ALTERNATIVES:
        ligne[f"R_{nom}"] = NAN
        ligne[f"p_{nom}"] = NAN
        ligne[f"favorise_{nom}"] = ""
    return ligne


def analyser_distribution(x, rng, nb_bootstrap=LP_NB_BOOTSTRAP, nb_candidats=LP_NB_CANDIDATS_XMIN,
                          nb_min_queue=LP_NB_MIN_QUEUE, seuil_p=LP_SEUIL_P, avec_alternatives=True):
    """
    Ajuste une loi de puissance a la queue de x, teste son adequation et la compare aux alternatives.

    Entree :
        x                 : observations (durees de sejour en s, distances en m...) ; les valeurs
                            non positives ou non finies sont ignorees
        rng               : numpy.random.Generator (bootstrap : reproductibilite)
        nb_bootstrap      : simulations de la p-valeur d'adequation (0 = ne pas la calculer)
        avec_alternatives : comparer aux quatre alternatives (plus lent : optimisations numeriques)

    Sortie : dict a plat
        n, n_queue, part_queue       taille de l'echantillon, de la queue, part de la queue
        xmin, alpha, sigma_alpha     seuil, exposant de la densite, son ecart-type
        ks                           distance de Kolmogorov-Smirnov de l'ajustement
        p_bootstrap, nb_bootstrap    p-valeur d'adequation et nombre de simulations
        exposant_survie              alpha - 1
        dans_domaine_on_off          True si 2 < alpha < 3 (domaine de H = (3 - a) / 2)
        h_on_off_predit              (4 - alpha) / 2 si dans le domaine, sinon nan
        verdict                      voir l'en-tete du module
        alternatives_meilleures      alternatives significativement meilleures, separees par "+"
        meilleur_modele              modele de plus grand poids d'Akaike
        poids_aicc_<modele>          poids d'Akaike de chacun des cinq modeles
        R_<alt>, p_<alt>, favorise_<alt>   rapport de vraisemblance, p-valeur et conclusion par alternative
    """
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x) & (x > 0)]
    ajustement = ajuster_loi_de_puissance(x, nb_candidats, nb_min_queue)
    if ajustement is None:
        return _resultat_vide(len(x))

    ligne = _resultat_vide(len(x), verdict="indetermine")
    alpha = ajustement.alpha
    domaine = bool(2.0 < alpha < 3.0)
    ligne.update(xmin=ajustement.xmin, alpha=alpha, sigma_alpha=ajustement.sigma_alpha,
                 n_queue=ajustement.n_queue, part_queue=ajustement.n_queue / len(x), ks=ajustement.ks,
                 exposant_survie=alpha - 1.0, dans_domaine_on_off=domaine,
                 h_on_off_predit=(4.0 - alpha) / 2.0 if domaine else NAN)

    if nb_bootstrap > 0:
        ligne["p_bootstrap"] = p_valeur_adequation(x, ajustement, rng, nb_bootstrap, nb_candidats, nb_min_queue)
        ligne["nb_bootstrap"] = int(nb_bootstrap)

    meilleures = []
    if avec_alternatives:
        queue = x[x >= ajustement.xmin]
        comparaison = comparer_modeles(queue, ajustement.xmin, alpha, seuil_p)
        for nom, poids in comparaison["poids_aicc"].items():
            ligne[f"poids_aicc_{nom}"] = poids
        for nom, c in comparaison["comparaisons"].items():
            ligne[f"R_{nom}"] = c["R"]
            ligne[f"p_{nom}"] = c["p"]
            ligne[f"favorise_{nom}"] = c["favorise"]
            if c["favorise"] not in ("loi_de_puissance", "indecidable"):
                meilleures.append(nom)
        ligne["meilleur_modele"] = comparaison["meilleur_modele"] or ""
        ligne["alternatives_meilleures"] = "+".join(meilleures)

    p = ligne["p_bootstrap"]
    if np.isfinite(p):
        if p <= seuil_p:
            ligne["verdict"] = "rejetee"
        elif meilleures:
            ligne["verdict"] = "alternative_meilleure"
        else:
            ligne["verdict"] = "plausible"
    return ligne
